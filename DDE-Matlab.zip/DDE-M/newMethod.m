addpath 'SKWGIF'
addpath 'WGIF'
addpath 'GDGIF'
addpath 'WAGIF'
close all;

clear;
%I = double(imread('C:\Users\24563\Desktop\infraredProject\reference\SKWGIF CODE\images\tulips.bmp')) / 255;

% �� .raw �ļ�
fileID = fopen('C:\Users\24563\Desktop\contrastEnhancement\experiment\1\A1_Origin.png', 'r');

% ��ȡ����
% I = fread(fileID, [640, 512], 'uint16');
I = double(imread('C:\Users\24563\Desktop\contrastEnhancement\experiment\61\A1_Origin.png')) / 255;
%I = rot90(I,-1);
%I = flip(I, 2);
%I = mat2gray(I);

% �������
p = I;r = 4;eps =0.36;h = 2.4;

% �˲�
tic
[q,mean_a] = SteeringKernel_WGIF(I, p, r, eps, h);
toc
disp(['����ʱ��: ',num2str(toc)]);
%q_GIF = guidedfilter(I, p, r, eps);
% ϸ����ȡ and ��ǿ
detailLayer=I-q;
detailLayer = (5.*mean_a+3).*detailLayer;
% �Աȶ���ǿ
% baseLayer = adapthisteq(q, 'NumTiles', [2 2], 'ClipLimit', 0.02, 'Distribution', 'rayleigh');
baseLayer = newContrast_0to1(q);

% �ں�
finalImage = detailLayer +baseLayer;
%finalImage = (1-mean_a).*baseLayer + mean_a.*detailLayer;

%dst = mat2gray(dst);
figure;
imshow(I);
title('I');

figure;
imshow(finalImage);
title('finalImage');

imwrite(I,'I.tiff');
%finalImage = mat2gray(finalImage);
imwrite(finalImage,'finalImage.tiff');

figure;
imshow([I,q,baseLayer,detailLayer,finalImage]);
title('I,q,baseLayer,detailLayer,finalImage');


clear



