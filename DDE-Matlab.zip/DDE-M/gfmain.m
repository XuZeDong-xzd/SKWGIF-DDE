addpath 'SKWGIF'
addpath 'WGIF'
addpath 'GDGIF'
addpath 'WAGIF'
close all;

%I = double(imread('C:\Users\24563\Desktop\infraredProject\reference\SKWGIF CODE\images\tulips.bmp')) / 255;

% �� .raw �ļ�
fileID = fopen('C:\Users\24563\Desktop\infraredProject\dataset\true\043.raw', 'r');

% ��ȡ����
I = fread(fileID, [640, 512], 'uint16');
I = rot90(I,-1);
I = flip(I, 2);
I = mat2gray(I);

% �������
p = I;r = 4;eps =0.36;h = 2.4;

% �˲�
q = sidewindow_guidedfilter(I, p, r, eps);
q2 = guidedfilter(I, p, r, eps);

%q_GIF = guidedfilter(I, p, r, eps);
% ϸ����ȡ and ��ǿ
detailLayer=I-q;
detailLayer = 2.5*detailLayer
%detailLayer = (5.*mean_a+2.5).*detailLayer;
% �Աȶ���ǿ
%baseLayer = adapthisteq(q_GIF, 'NumTiles', [2 2], 'ClipLimit', 0.01, 'Distribution', 'rayleigh');
baseLayer = newContrast_0to1(q);

% �ں�
finalImage = detailLayer + baseLayer;

%dst = mat2gray(dst);
figure;
imshow(I);
title('I');

figure;
imshow(finalImage);
title('finalImage');

imwrite(I,'I.tiff');
imwrite(finalImage,'finalImage.tiff');

figure;
imshow([I,q,baseLayer,detailLayer,finalImage]);
title('I,q,baseLayer,detailLayer,finalImage');


clear



