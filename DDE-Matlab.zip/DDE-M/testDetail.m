addpath 'SKWGIF'
addpath 'WGIF'
addpath 'GDGIF'
addpath 'WAGIF'
close all;

%I = double(imread('C:\Users\24563\Desktop\infraredProject\reference\SKWGIF CODE\images\tulips.bmp')) / 255;
I = double(imread('C:\Users\24563\Desktop\infraredProject\dataset\true\046_compress_img.png')) / 255;% if size(I,3)==3%     I=rgb2gray(I);% end
p = I;
r = 8;eps =0.64;h = 2.4;

q_bilateral = bfilter2(I,8) ; 
q_GIF = guidedfilter(I, p, r, eps);
q_WGIF =  WeightedGuidedImageFilter(I, p,r, eps);
q_GDGIF = gradient_guidedfilter(I, p,r, eps);
q_WAGIF =  WeightedAggregationGuidedImageFilter(I, p, r, eps,0.001 * 0.001 * 255 * 255);
q_SKWGIF = SteeringKernel_WGIF(I, p, r, eps, h);
q_SW_GIF = sidewindow_guidedfilter(I, p, r, eps);

figure;
imshow([I,q_bilateral,q_GIF,q_WGIF,q_GDGIF,q_WAGIF,q_SKWGIF,q_SW_GIF]);
title('I,bilateral,GIF,WGIF,GDGIF,WAGIF,SKWGIF,q_SW_GIF');

imwrite(q_GIF,'q_GIF.tif');
imwrite(q_WGIF,'q_WGIF.tif');
imwrite(q_WAGIF,'q_WAGIF.tif');
imwrite(q_GDGIF,'q_GDGIF.tif');
imwrite(q_SKWGIF,'q_SKWGIF.tif');
imwrite(q_bilateral,'q_bilateral.tif');
%imwrite(q_SW_GIF,'q_SW_GIF.tiff');

detail_SW_GIF = I-q_SW_GIF;
detail_GIF = I-q_GIF;
detail_WGIF = I-q_WGIF;
detail_WAGIF = I-q_WAGIF;
detail_GDGIF = I-q_GDGIF;
detail_SKWGIF = I-q_SKWGIF;
detail_bilateral = I-q_bilateral;

detail_SW_GIF = (detail_SW_GIF - min(detail_SW_GIF(:))) / (max(detail_SW_GIF(:)) - min(detail_SW_GIF(:)));
detail_GIF = (detail_GIF - min(detail_GIF(:))) / (max(detail_GIF(:)) - min(detail_GIF(:)));
detail_WGIF = (detail_WGIF - min(detail_WGIF(:))) / (max(detail_WGIF(:)) - min(detail_WGIF(:)));
detail_WAGIF = (detail_WAGIF - min(detail_WAGIF(:))) / (max(detail_WAGIF(:)) - min(detail_WAGIF(:)));
detail_GDGIF = (detail_GDGIF - min(detail_GDGIF(:))) / (max(detail_GDGIF(:)) - min(detail_GDGIF(:)));
detail_SKWGIF = (detail_SKWGIF - min(detail_SKWGIF(:))) / (max(detail_SKWGIF(:)) - min(detail_SKWGIF(:)));
detail_bilateral = (detail_bilateral - min(detail_bilateral(:))) / (max(detail_bilateral(:)) - min(detail_bilateral(:)));





imwrite(detail_bilateral,'detail_bilateral.tif');
imwrite(detail_GIF,'detail_GIF.tif');
imwrite(detail_WGIF,'detail_WGIF.tif');
imwrite(detail_GDGIF,'detail_GDGIF.tif');
imwrite(detail_WAGIF,'detail_WAGIF.tif');
imwrite(detail_SKWGIF,'detail_SKWGIF.tif');
%imwrite(detail_SW_GIF,'detail_SW_GIF.tiff');

figure;
imshow(detail_SW_GIF,[]);
title('detail_SW_GIF');
figure;
imshow(detail_bilateral,[]);
title('detail-bilateral');
figure;
imshow(detail_GIF,[]);
title('detail_GIF');
figure;
imshow(detail_WGIF,[]);
title('detail_WGIF');
figure;
imshow(detail_GDGIF,[]);
title('detail_GDGIF');
figure;
imshow(detail_WAGIF,[]);
title('detail_WAGIF');
figure;
imshow(detail_SKWGIF,[]);
title('detail_SKWGIF');
figure;
imshow([detail_bilateral,detail_GIF,detail_WGIF,detail_GDGIF,detail_WAGIF,detail_SKWGIF],[]);
title('detail-bilateral,detail-GIF,detail-WGIF,detail-GDGIF,detail-WAGIF,detail-SKWGIF');

figure;
imshow([detail_bilateral,detail_GIF,detail_WGIF,detail_GDGIF,detail_WAGIF,detail_SKWGIF],[]);

clear


% ��ʽ��������
%fprintf('ͼ������ֵ: %.2f,ͼ�����Сֵ: %.2f\n', max(detail_GIF(:)),min(detail_GIF(:)));
%fprintf('ͼ������ֵ: %.2f,ͼ�����Сֵ: %.2f\n', max(detail_WGIF(:)),min(detail_WGIF(:)));
%fprintf('ͼ������ֵ: %.2f,ͼ�����Сֵ: %.2f\n', max(detail_WAGIF(:)),min(detail_WAGIF(:)));
%fprintf('ͼ������ֵ: %.2f,ͼ�����Сֵ: %.2f\n', max(detail_GDGIF(:)),min(detail_GDGIF(:)));
%fprintf('ͼ������ֵ: %.2f,ͼ�����Сֵ: %.2f\n', max(detail_SKWGIF(:)),min(detail_SKWGIF(:)));

