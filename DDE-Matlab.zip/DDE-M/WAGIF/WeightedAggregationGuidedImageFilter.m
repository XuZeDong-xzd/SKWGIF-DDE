function q = WeightedAggregationGuidedImageFilter(I, p, r, eps,lambda)
%   GUIDEDFILTER   O(1) time implementation of guided filter.
%
%   - guidance image: I (should be a gray-scale/single channel image)
%   - filtering input image: p (should be a gray-scale/single channel image)
%   - local window radius: r
%   - regularization parameter: eps

[hei, wid] = size(I);
N = boxfilter(ones(hei, wid), r); % the size of each local patch; N=(2r+1)^2 except for boundary pixels.

mean_I = boxfilter(I, r) ./ N;
mean_p = boxfilter(p, r) ./ N;
mean_Ip = boxfilter(I.*p, r) ./ N;
cov_Ip = mean_Ip - mean_I .* mean_p; % this is the covariance of (I, p) in each local patch.

mean_II = boxfilter(I.*I, r) ./ N;
mean_pp = boxfilter(p.*p, r) ./ N;
var_I = mean_II - mean_I .* mean_I;
var_P = mean_pp - mean_p .* mean_p;

a = cov_Ip ./ (var_I + eps); % Eqn. (5) in the paper;
b = mean_p - a .* mean_I; % Eqn. (6) in the paper;

e=a.*a.*var_I-2*a.*cov_Ip+var_P;
beta=exp(-e./lambda);

mean_beta=boxfilter(beta, r) ./ N;
n=2*r+1;
sum_beta=mean_beta*n;

beta_a=(beta.*a)./sum_beta;
beta_b=(beta.*b)./sum_beta;

mean_beta_a = boxfilter(beta_a, r) ./ N;
mean_beta_b = boxfilter(beta_b, r) ./ N;

q = (mean_beta_a .* I + mean_beta_b)*n; % Eqn. (8) in the paper;
end