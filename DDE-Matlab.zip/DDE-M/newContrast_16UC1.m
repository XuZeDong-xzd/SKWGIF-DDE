function dst = newContrast_16UC1(src)
    total_pixels = size(src, 1) * size(src, 2);
    hist = zeros(65536, 1);
    
    % ����ֱ��ͼ
    for r = 1:size(src, 1)
        for c = 1:size(src, 2)
            hist(src(r, c) + 1) = hist(src(r, c) + 1) + 1; % MATLAB ������ 1 ��ʼ
        end
    end

    % ��ֱ��ͼ�� PDF
    PDF = hist / total_pixels;

    % ��ֱ��ͼ�� PDF_W �� CDF_W
    pdf_min = min(PDF);
    pdf_max = max(PDF);
    PDF_w = PDF;
    for i = 1:65536
        PDF_w(i) = pdf_max * ((PDF_w(i) - pdf_min) / (pdf_max - pdf_min))^0.5;
    end

    CDF_w = zeros(65536, 1);
    culsum = 0;
    for i = 1:65536
        culsum = culsum + PDF_w(i);
        CDF_w(i) = culsum;
    end
    CDF_w = CDF_w / culsum;

    % ����ֵӳ��
    table = zeros(65536, 1);
    pdf_min = double(min(src(:)));
    pdf_max = double(max(src(:)));

    for i = 2:65536
        table(i) = uint16(pdf_min + (pdf_max - pdf_min) * (CDF_w(i) - 0.5 * PDF_w(i)));
    end

    dst = zeros(size(src), 'uint16');
    for i = 1:size(src, 1)
        for j = 1:size(src, 2)
            dst(i, j) = table(src(i, j) + 1); % MATLAB ������ 1 ��ʼ
        end
    end
end
