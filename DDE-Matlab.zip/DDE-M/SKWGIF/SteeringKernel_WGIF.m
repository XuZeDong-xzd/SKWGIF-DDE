function [q,mean_a] = SteeringKernel_WGIF(I, p, r, eps, h)
% I    : the guidance image
% p    : the input image to be filtered
% r    : the radius of local window;
% eps  : the regularization parameter
% h    : the global smoothing parameter
% q    : the filtering output of p

% compute the linear coefficients
[a, b] = compute_ab(I, p, r, eps);
spmd
  I1 = I(:,(labindex-1)*end/4+1:min((labindex*end/4+r), end), :);
  a1 = a(:, (labindex-1)*end/4+1:min((labindex*end/4+r), end), :);
  b1 = b(:, (labindex-1)*end/4+1:min((labindex*end/4+r), end), :);  
  [q0,mean_a0] = SKWGIF(I1, a1, b1, r, h);
end
q1 = q0{1}; q2 = q0{2};
q3 = q0{3}; q4 = q0{4};

mean_a1 = mean_a0{1}; mean_a2 = mean_a0{2};
mean_a3 = mean_a0{3}; mean_a4 = mean_a0{4};

mean_a = [mean_a1(:, 1:end-r, :), mean_a2(:, 1:end-r, :), mean_a3(:, 1:end-r, :), mean_a4];
q = [q1(:, 1:end-r, :), q2(:, 1:end-r, :), q3(:, 1:end-r, :), q4];
end


