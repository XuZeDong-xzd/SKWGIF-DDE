function [a, b] = compute_ab(I, p, r, eps)

% I      : guidance image
% p      : input image
% r      : the radius of local window
% eps    : regularization parameter
r1=1; % the radius of local to compute the edge-aware weighting
[hei, wid, cha] = size(I);
N = boxfilter(ones(hei, wid), r);
N1 = boxfilter(ones(hei, wid), r1);

mean_I = zeros(hei, wid, cha);
mean_p = mean_I;
mean_Ip = mean_I;
mean_II = mean_I;
mean_I2 = mean_I;
mean_II2 = mean_I;

for i = 1 : cha
    mean_I(:, :, i) = boxfilter(I(:, :, i), r) ./ N;
    mean_p(:, :, i) = boxfilter(p(:, :, i), r) ./ N;
    mean_Ip(:, :, i) = boxfilter(I(:, :, i) .* p(:, :, i), r) ./ N;
    mean_II(:, :, i) = boxfilter(I(:, :, i) .* I(:, :, i), r) ./ N;
    mean_I2(:, :, i) = boxfilter(I(:, :, i), r1) ./ N1;
    mean_II2(:, :, i) = boxfilter(I(:, :, i) .* I(:, :, i), r1) ./ N1;
end

cov_Ip = mean_Ip - mean_I .* mean_p;
var_I = mean_II - mean_I .* mean_I;
var_I2 = mean_II2 - mean_I2 .* mean_I2;

if cha == 3
    L = 1;
else
    L = 255;
end

lambda = (0.001 * L)^2;
psi = zeros(hei, wid, cha);
w = fspecial('gaussian',[3 3],0.5);
for i = 1 :cha
    psi0 = (var_I2(:, :, i) + lambda) * sum(sum(1./(var_I2(:, :, i) + lambda))) / (hei * wid);
    psi(:, :, i) = imfilter(psi0, w, 'replicate');
end
a = cov_Ip ./ (var_I + eps ./ psi);
b = mean_p - a .* mean_I;
end
