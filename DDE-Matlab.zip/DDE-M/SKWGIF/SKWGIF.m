function [q,mean_a] = SKWGIF(I, a, b, r, h)
% I    : the guidance image
% a, b : the linear coefficient
% r    : the radius of local window;
% h    : the global smoothing parameter
% q    : the filtering output

% estimate the gradient image along x1 and x2 directions
[z, zx1c, zx2c] = ckr2_regular(I, 0.5, 1, 5);
% compute steering matrix
C = steering(zx1c, zx2c, ones(size(I(:, :, 1))), r, 1, 0.5);
%compute the weighted average of linear coefficients a and b
[mean_a, mean_b] = WeightedAverage(I, a, b, C, r, h);
% the filtering output
q = mean_a .* I + mean_b;
end