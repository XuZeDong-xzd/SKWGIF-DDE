function [mean_a, mean_b] = WeightedAverage(I, a, b, C, r, h)

% I      : the guidance image
% a, b   : the linear coefficients
% C      : the steering matrices
% r      : the radius of local window
% h      : the global smoothing parameter
% mean_a : the weighted average of a by steering kernel
% mean_b : the weighted average of b by steering kernel

[N, M, cha] = size(I);
[xx2, xx1] = meshgrid(-r :  r, -r :  r);

% pre-culculation for covariance matrices
C11 = zeros(N, M);
C12 = zeros(N, M);
C22 = zeros(N, M);
sq_detC = zeros(N, M);

for m = 1 : M  
    for n = 1 : N
        C11(n,m) = C(1,1,n,m);
        C12(n,m) = C(1,2,n,m);
        C22(n,m) = C(2,2,n,m);
        sq_detC(n,m) = sqrt(det(C(:,:,n,m)));
    end
end

% Mirroring
C11 = EdgeMirror(C11, [r, r]);
C12 = EdgeMirror(C12, [r, r]);
C22 = EdgeMirror(C22, [r, r]);
sq_detC = EdgeMirror(sq_detC, [r, r]);

a = padarray(a, [r, r], 'replicate');
b = padarray(b, [r, r], 'replicate');
mean_a = zeros(N, M, cha);
mean_b = mean_a;
ksize = 2 * r + 1;
for m = 1 : M
    for n = 1 : N      
        % Neighboring samples to be taken account into the estimation
        % compute the weight matrix
        tt = xx1 .* (C11(n:n+ksize-1, m:m+ksize-1) .* xx1...
            + C12(n:n+ksize-1, m:m+ksize-1) .* xx2)...
            + xx2 .* (C12(n:n+ksize-1, m:m+ksize-1) .* xx1...
            + C22(n:n+ksize-1, m:m+ksize-1) .* xx2);
        W = exp(-(0.5/h^2) * tt) .* sq_detC(n:n+ksize-1, m:m+ksize-1);
        W = W ./ sum(sum(W));
        for i = 1 : cha
            mean_a(n, m, i) = sum(sum(W .* a(n:n+ksize-1, m:m+ksize-1, i)));
            mean_b(n, m, i) = sum(sum(W .* b(n:n+ksize-1, m:m+ksize-1, i)));
        end
    end
end
end