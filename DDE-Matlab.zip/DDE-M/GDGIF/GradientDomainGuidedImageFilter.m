function q = GradientDomainGuidedImageFilter(I, p, r, lam)
[hei, wid] = size(I);
N = boxfilter(ones(hei, wid), r); 
mean_I = boxfilter(I, r) ./ N;  
mean_p = boxfilter(p, r) ./ N;
mean_Ip = boxfilter(I.*p, r) ./ N;
cov_Ip = mean_Ip - mean_I .* mean_p; 
mean_II = boxfilter(I.*I, r) ./ N;
var_I = mean_II - mean_I .* mean_I;

L = 255;
delta = (0.001 * L)^2;
N_3 = boxfilter(ones(hei, wid), 1);
mean_II_3 = boxfilter(I.*I, 1) ./ N_3;
mean_I_3 = boxfilter(I, 1) ./ N_3;
var_I_3 = mean_II_3 - mean_I_3 .* mean_I_3;
Chi_I = sqrt(var_I_3) .* sqrt(var_I);
Gamma_I = (Chi_I + delta) .* (sum(sum(1 ./ (Chi_I + delta))) / (hei * wid)); % Eqn. (9) in the paper;
eta = 4 / (mean2(Chi_I) - min(min(Chi_I)));
gamma_I = 1 - 1 ./ (1 + exp(eta * (Chi_I - mean2(Chi_I)))); % Eqn. (11) in the paper;

a = (cov_Ip + (lam ./ Gamma_I) .* gamma_I) ./ (var_I + (lam ./ Gamma_I)); % Eqn. (12) in the paper;
b = mean_p - a .* mean_I; % Eqn. (13) in the paper;
mean_a = boxfilter(a, r) ./ N;
mean_b = boxfilter(b, r) ./ N;
q = mean_a .* I + mean_b; % Eqn. (14) in the paper;
end